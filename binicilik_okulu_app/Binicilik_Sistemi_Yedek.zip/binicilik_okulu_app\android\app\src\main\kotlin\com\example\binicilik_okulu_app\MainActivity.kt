package com.example.binicilik_okulu_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
